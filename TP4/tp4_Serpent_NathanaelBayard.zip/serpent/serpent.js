// taille du terrain
const LARGEUR = 800;
const HAUTEUR = 300;
// les 4 directions
const BAS ='ArrowDown';
const HAUT ='ArrowUp';
const GAUCHE ='ArrowLeft';
const DROITE ='ArrowRight';
// direction de déplacement du serpent
var direction = DROITE; 
// le nb de fruits
var nbFruits = 10;
// le jeu
var jeu;

const dirs = [BAS, HAUT, GAUCHE, DROITE];
  // ^ directions possibles
const pas = 10; // en px, la distance parcourrue par intervalle
const tailleSerpent = 50; //px
const maxBas = HAUTEUR - tailleSerpent;
const minHaut = 0;
const minGauche = 0;
const maxDroite = LARGEUR - tailleSerpent;
  // ^ positions extremes

var serpent = byId("c1");
var start = byId("start");
var pause = byId("pause");
var posh = 10;
var posv = 10;
  // ^ position verticale et horizontale, en px

const tailleFruit = 10;
var nbFruitsManges = 0;

var enPause = true;
  // ^ variable necessaire car sinon cliquer
  // sur "start" lorsque le jeu n'est pas en pause
  // provoquerait un bug.
var finPartie = false;

function avancer(){
  switch(direction){
    case BAS:
      posv = min(posv + pas, maxBas);
      break;
    case HAUT:
      posv = max(posv - pas, minHaut);
      break;
    case GAUCHE:
      posh = max(posh - pas, minGauche);
      break;
    case DROITE:
      posh = min(posh + pas, maxDroite);
      break;
  }
  serpent.style.top = posv + "px";
  serpent.style.left = posh + "px";

  checkCollisions();
  updateFruitCount();
}

body.addEventListener("keypress", function (e){
  if (dirs.includes(e.key)) direction = e.key;
}, false);


start.onclick = function (e){
  if (enPause) {
    enPause = false;
    if (finPartie) { // on recommence
      finPartie = false;
      fruits(nbFruits);
      nbFruitsManges = 0;
    }
    jeu = setInterval(avancer, 100);
  }
};

pause.onclick = function (e){
  clearInterval(jeu);
  enPause = true;
};


function fruits(combien){
  repeatAction(combien, unFruit);
}

function unFruit(index){
  var fruit = newEl("div");
  fruit.className = "fruit";
  fruit.id = "f" + (index + 1);
  fruit.style.top = randN(HAUTEUR - tailleFruit) + "px";
  fruit.style.left = randN(LARGEUR - tailleFruit) + "px";
  terrain.appendChild(fruit);
}

function checkCollisions(){
  map_(checkOneCollision, copyList(byClass("fruit")));
}

function checkOneCollision(fruit){
  if ( fruit.offsetLeft > serpent.offsetLeft - tailleFruit
    && fruit.offsetLeft < serpent.offsetLeft + tailleSerpent
    && fruit.offsetTop > serpent.offsetTop - tailleFruit
    && fruit.offsetTop < serpent.offsetTop + tailleSerpent
    ) {
    terrain.removeChild(fruit);
  }
}

function updateFruitCount(){
  nbFruitsManges = nbFruits - byClass("fruit").length;
  byId("nbFruitsManges").value = nbFruitsManges;
  if (nbFruitsManges == nbFruits) {
    partieGagnee();
  }
}


function partieGagnee(){
  finPartie = true;
  alert("Vous avez gagné !");
  pause.onclick();
}

// -----------
fruits(nbFruits);
byId("nbFruitsManges").value = 0;