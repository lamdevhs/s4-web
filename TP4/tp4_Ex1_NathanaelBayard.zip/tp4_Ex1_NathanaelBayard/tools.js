function byId(id) {
  return document.getElementById(id);
}

function log(v) {
  console.log(v);
}

function mapObj_(f, o){
  for (var k in o) {
    if (o.hasOwnProperty(k)) {
      f(k, o[k]);
    }
  }
}


var doc = document;