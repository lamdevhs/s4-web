// utilise les fonctions du fichier tools.js

// 1)
// a) La page est rechargee avec une URL contenant les valeurs entrees.

var form = byId("f1");
form.addEventListener("submit", function(e){
  var data = dataFromForm();
  if (checkForm(data)) { // si tout va bien:
    var str = "Données entrées:\n";
    mapObj_(function (label, input){
      str += label + ": " + input.value + "\n";
    }, data);
    alert(str);
  }
  else {
    alert("Les données du formulaire sont incorrectes.");
    e.preventDefault();
  }
}, false);


// get a dictionnary of form labels and matching input elements
function dataFromForm(){
  var output = {};
  var labels = doc.querySelectorAll("#f1 label");
  labels.forEach(function (label){
    // get the 'for="zzz"' string
    // use it to get the input element that corresponds
    // but takes the label as key for the dictionnary
    output[label.innerHTML] = byId(label.htmlFor);
  });
  return output;
}

function checkForm(data){
  var nom = data["nom"];
  var prenom = data["prénom"];
  var mail = data["mail"];
  var allok = true;
  if (nom.value === "") {
    byId("error_nom").innerHTML = "champ obligatoire";
    allok = false;
  }
  else byId("error_nom").innerHTML = "";
  if (prenom.value === "") {
    byId("error_prenom").innerHTML = "champ obligatoire";
    allok = false;
  }
  else byId("error_prenom").innerHTML = "";
  if (!onceOnly(mail.value, "@")) {
    byId("error_mail").innerHTML =
      "un email doit contenir exactement un caractère '@'";
    allok = false;
  }
  else byId("error_mail").innerHTML = "";
  
  return allok;
}

function onceOnly(str, substr){
  var ix = str.indexOf(substr);
  if (ix === -1) return false;
  return (ix === str.lastIndexOf(substr));
    // ^ une seule occurence si et seulement si
    // la premiere egale la derniere
}